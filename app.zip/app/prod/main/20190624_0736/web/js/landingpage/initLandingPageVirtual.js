define([
    'jquery',
    'lodash',
    'loc',
    'environment',
    'fastdom',
    'landingPageUtils',
    'trackerUtils',

], function(
    $,
    _,
    loc,
    env,
    fastdom,
    landingPageUtils,
    trackerUtils
) {
    'use strict';


    var writeRoomNumber = function(room) {

        ga('send', 'event', 'room-nr', room.toString().substr(0, 1));

        fastdom.read(function() {
            var roomNumbers = document.querySelectorAll('.room-number');

            fastdom.write(function() {
                // Update room number(s)
                document.querySelector('html').classList.add('room-number');
                for (var i = 0; i < roomNumbers.length; i++) {
                    roomNumbers[i].innerHTML = room;
                }
            });
        });
    };

    var displayQrCode = function(qrCode) {

        /// hide spinner
        $(".dr-landing .init-spinner").hide(0.3);

        $(".dr-landing__wrapper").removeClass("dr-landing--hidden");

        //replace with qrCode
        var qrCodeContainer = document.querySelector('.qr-code');
        if (!!qrCodeContainer) {
            var qrCode = landingPageUtils.scaleQrCode(qrCode, qrCodeContainer.clientWidth);
            qrCodeContainer.appendChild(qrCode);
        }

    };

    function InitLandingPageVirtual() {
        this.displayRoomNumber = true;
    };

    var _this = InitLandingPageVirtual.prototype;

    //initialize the view and create its container
    _this.init = function(igs) {
        return $.when(!!this.initLandingPage ?
            this.initLandingPage(igs) :
            null);
    };

    _this.handleTearDown = function() {
        return $.when(!!this.tearDown ?
            this.tearDown() :
            null);
    };

    _this.initializeGame = function(igs) {

        var $launchGame = $('.launch-game'),
            dfd = $.Deferred(),
            gameInitDfd = igs.getGameInitialized();

        if (this.displayRoomNumber) {
            $launchGame.addClass('visible');
            $launchGame.on('click', function() {
                dfd.resolve.call(igs, true);

                //Tracking calls
                if ($(this).hasClass('enter--pairing')) {
                    trackerUtils.trackClickEvents('Action - Home - Room Number');
                } else {
                    trackerUtils.trackClickEvents('Action - Home - Try It For Free');
                }
            });


            gameInitDfd
                .then(function(roomInfos) {
                    writeRoomNumber(roomInfos.room);
                    displayQrCode(roomInfos.qrCode);
                });


        } else {
            dfd.resolve.call(igs, false);
        }


        if (this.initialize) {
            gameInitDfd
                .then(function() {
                    this.initialize(igs);
                }.bind(this));
        }

        return dfd;

    };

    return InitLandingPageVirtual;

});