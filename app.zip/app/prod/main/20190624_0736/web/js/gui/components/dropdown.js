define([
    'jquery',
    'language',
    'utils',

    'text!html/jd/dropdown.html'
], function(
    $,
    language,
    utils,

    dropdownHtml
) {
    'use strict';

    function Dropdown() {
        console.log('%c✔', 'color:#339933; background:#CCFF00', 'Dropdown language initialized');
    };

    Dropdown.prototype = {
        init: function() {
            var self = this;
            this.url = window.location.href;
            this.$html = $('html');

            this.$Parent = $('.dropdown__parent');
            this.$Parent.append(dropdownHtml);

            this.$Dropdown = this.$Parent.find('.dropdown');
            this.$DropdownTxt = this.$Dropdown.find('.dropdown__txt');
            this.$DropdownUL = this.$Dropdown.find('.menu__dropdown');

            this.$Dropdown.on('click', self.toggle.bind(self));

            this.build();
            this.bindEvent();
        },

        toggle: function() {
            this.$DropdownUL.slideToggle("slow");
        },

        destroy: function() {
            // for garbage collection in js
            this.url = this.$Parent = this.$Dropdown = null;
            this.$DropdownUL = this.$DropdownLI = this.$DropdownTxt = null;
        },

        build: function() {
            var $strHtml;
            this.$DropdownTxt.text(language[lang]);
            this.$DropdownTxt.attr('data-lang', lang)

            for (var key in language) {
                if (!language.hasOwnProperty(key)) return;

                $strHtml = '<li class="menu__dropdown-li" data-lang=' + key + '>' + language[key] + '</li>'
                this.$DropdownUL.append($strHtml);
            }
        },

        bindEvent: function() {
            var self = this;
            this.$DropdownLI = this.$Dropdown.find('.menu__dropdown-li');

            this.$DropdownLI.on('click', function() {
                var txtVal = $(this).text(),
                    langVal = $(this).attr('data-lang');

                self.$DropdownTxt.text(txtVal);
                self.changeUrl(langVal);
            });

            this.$html.on('click', function(e) {
                if (!$(e.target).closest('.dropdown__parent').length) {
                    self.$DropdownUL && self.$DropdownUL.hide();
                }
            });
        },

        //Change URL & redirect to the reuqired lang URL
        changeUrl: function(language, url) {
            var debug = utils.getParameterByName('debug');

            if (debug === null) {
                document.location.search = 'lang=' + language;
            } else {
                document.location.search = '?debug&lang=' + language;
            }
        }

    };

    return Dropdown;

});