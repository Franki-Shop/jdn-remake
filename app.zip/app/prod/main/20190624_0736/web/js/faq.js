(function() {
	'use strict';

    //Constants for mapping questions
    var questionConstant = {
        howToPlayOnComputer : 7,
        howToPlayOnTablet : 8,
        howToPlayOnAppleTV : 9,
        whatIsQrCode : 11,
        whatIsRoomNumber : 12,
        listOfCompatibleDevices : 13
    }
    var TIME_INTERVAL = 1000; // in milisecs

    //Page load functions
	pageAlign();
    $(window).resize(function() {
        pageAlign();
    });

    focusQuestionFromUrl();


    //CSTS redirect for web & unity
    var isMobileApp = $('.primary__faq').attr('data-objMobileApp');
    var isIpadApp = $('.primary__faq').attr('data-objIpadApp');
    var dancerID = getParameterByName('dcid'); //For Unity-web view, getting the DCID value from param

    renderDancerId(isMobileApp, dancerID);
    $('.link--report').on('click', function(e) {
        e.preventDefault();
        if (!!dancerID) {
            window.location.href = "uniwebview://CSTSLINK" + "";
        } else {
            window.open('https://support.ubi.com/', '_blank');
        }
    });

    
    // EXPANDABLE FAQ
    var $faqElements = $('.viewport-content h3');
    $faqElements.on('click', function(e) {
        e.preventDefault();
        if (isIpadApp !== 'true') {
            $(this).toggleClass('expanded');
        }
    });


    //detect highlighted section
    function focusSection(val) {
        var $scrollElem = $('.viewport-content article').eq(val);

        smooth_scroll_to($scrollElem, $('html'));
    }

    //Scrolling element function
    function smooth_scroll_to(elem, parentElem) {
        elem[0].children[0].classList.add('expanded');

        var offset = 0;
        offset = elem.position().top;

        parentElem.delay(100).animate({
            scrollTop: offset
        }, TIME_INTERVAL);
    }

    //Window alignment function
    function pageAlign() {
        var window_height = $(window).height(), window_width = $(window).width(),
            header_height = $('.header--faq').outerHeight(true),
            faq_height = $('.primary__faq header').outerHeight(true),
            btn_height = $('.section__report').outerHeight(true),
            $viewport_content = $('.viewport-content');

        var sc_mobile = window_height - (header_height + btn_height + faq_height + 40);

        if (window_width <= 800) {
            $viewport_content.css('height', sc_mobile+'px');
        } else {
            $viewport_content.css('height', 'auto');
        }
    }

    //Focus specific question on pageload
    function focusQuestionFromUrl() {
        var questionID = getParameterByName('question');
        if(!questionID) { return; }

        var eI = questionConstant[questionID];
        if(!eI) { return; }

        focusSection(eI);
    }

    function renderDancerId(isMobileApp, dancerID) {
        if (isMobileApp === 'true' && !!dancerID) {
            $('#dcid').text(dancerID);
        }
    }

    //Fetch value from URL param
    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }


}());
