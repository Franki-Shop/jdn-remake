(function() {
    'use strict';

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //      TRACKING FILES to be loaded
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

    var detectScreenTrackingState = function() {
        var trackingVal = $.cookie("jdn-screen-tracking"); //expires in more or less 10 years
        if (trackingVal === undefined) {
            trackingVal = (Math.floor(Math.random() * 10) === 0);
            $.cookie("jdn-screen-tracking", trackingVal, {
                expires: 365 * 10
            });
        } else {
            return trackingVal === "true";
        }
        return trackingVal;
    }

    // detect if we are tracking the screen (sampling 1/10)
    window.is_screen_tracked = detectScreenTrackingState();
    if (!window.is_screen_tracked) {
        return;
    }


    /* Tag Commander with Cache Buster */
    /* Data Layer Loader */
    var a = Math.random() * 10000000000000;
    var trackLoadArr = [];


    /** Asynchronous loading of files & callbacks registering **/
    function loadScript(url, uniqueId, callback) {
        var script = document.createElement("script");
        script.id = uniqueId;
        script.type = "text/javascript";
        if (script.readyState) { //IE
            script.onreadystatechange = function() {
                if (script.readyState === "loaded" || script.readyState === "complete") {
                    script.onreadystatechange = null;
                    callback();
                }
            };
        } else { //Others
            script.onload = function() {
                callback();
            };
        }

        script.src = url;
        document.body.appendChild(script);
    }

    /** Call the tracker events if all files are loaded successfully **/
    function callTracker() {
        if (trackLoadArr.length < 3) {
            return;
        } else {
            window.sendEventsToTracker();
        }
    }


    loadScript('//ubistatic2-a.akamaihd.net/worldwide_analytics/tagcommander/justdance/Now/wa_data_Now.js?rand=' + a, 'justdancenow_datalayer', function() {
        trackLoadArr.push('loaded file1');
        callTracker();
    });
    loadScript('//ubistatic2-a.akamaihd.net/worldwide_analytics/tagcommander/js/tc_UbiWorldWide_1.js?rand=' + a, 'tc_UbiWorldwide', function() {
        trackLoadArr.push('loaded file2');
        callTracker();
    });
    loadScript('//ubistatic2-a.akamaihd.net/emea/gamesites/justdance/tagcommander/js/tc_justdance_2.js?rand=' + a, 'justdancenow', function() {
        trackLoadArr.push('loaded file3');
        callTracker();
    });

}());