(function() {
	'use strict';


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //      TRACKING DATA
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var initTrackingHome = function() {
        var date = new Date();
        window.initialTime = date.getTime();


        if (!window.wa_data) {
            window.wa_data = {
                nav: {}
            };
            wa_data.nav["siteCategory"] = "" ? "Desktop" : "Mobile";
            wa_data.nav["environment"] = (environment.search("prod") > 0 ? "PROD" : "UAT");
            wa_data.nav["siteType"] = "Portal";
            wa_data.nav["siteName"] = "Just Dance Now";
            wa_data.nav["mdm Brand ID"] = "347 - JUST DANCE";
            wa_data.nav["mdm Installment ID"] = "4729 - JUST DANCE 2016";
            wa_data.nav["pageName"] = "Play"; //Dummy data
            wa_data.nav["siteSection"] = "Home pages";
            wa_data.nav["siteSubSection"] = "";
            wa_data.nav["country"] = country;
            wa_data.nav["language"] = lang;
            //wa_data.nav["genomeID"] = ""; //Not needed, remove it
            wa_data.nav["doNotTrack"] = true ? "ACTIVE" : "NOT_ACTIVE";
            //wa_data.nav["xpCustomVariable"] = ""; //Not needed, remove it
            wa_data.nav["uplayID"] = ""; //If connected, example : "8b8dbe14-a6fd-43c5-9208-93911160a9d2". Fetch the dynamic value
            wa_data.nav["dancerID"] = ""; //If connected, then player ID displayed
        }  
    };


    initTrackingHome();

}());
