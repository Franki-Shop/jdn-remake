define([
    'jquery',
    'lodash',
    'utils',
    'videoPlayer',
    'hlsplayer',
    'bowser'
], function(
    $,
    _,
    utils,
    VideoPlayer,
    hlsplayer,
    bowser
) {
    'use strict';

    // Helper functions
    var delegate = function(functionName) {
        return function() {
            return hlsplayer[functionName].apply(hlsplayer, arguments);
        };
    };
    // HLS player used variables
    var lastStartPosition, lastDuration;
    var hls_stream_data = {},
        self_player;


    // Wrapper around HLSPlayer, which provides us with HLS playback capabilities on
    // platforms that does not natively support it, through a Flash component.
    function HLSPlayer(containerId) {
        VideoPlayer.call(this);
        this.id = _.uniqueId('video-player');
        this.name = 'HLSPlayer';
        this.$container = $('#' + containerId).html('<div id="' + this.id + '"><video id="in-game_video"></video></div>');
    }
    var me = HLSPlayer.prototype = Object.create(VideoPlayer.prototype);
    HLSPlayer.prototype.constructor = HLSPlayer;


    me.load = function() {
        VideoPlayer.prototype.load.apply(this, arguments);

        var $player = $('#' + this.id);
        if (!$player.length) {
            throw 'The container element must be attached to the DOM';
        }


        var video = $('#in-game_video')[0],
            self = this;

        // reset player error flag each time while HLS player initiation
        self.resetPlayerErrorFlag();

        // Start loading HLS player config, version 0.11.0
        if (hlsplayer.isSupported()) {

            var lastLevel = sessionStorage.getItem('lastPlayerLevel');

            var config = {
                startLevel: lastLevel,
                autoStartLoad: true,
                startPosition: -1,
                capLevelToPlayerSize: false,
                debug: false,
                initialLiveManifestSize: 1,
                maxBufferLength: 30,
                maxMaxBufferLength: 600,
                maxBufferSize: 60 * 1000 * 1000,
                maxBufferHole: 0.5,
                maxFragLookUpTolerance: 0.2,
                liveSyncDuration: 3,
                liveMaxLatencyDuration: 10,
                enableWorker: true,
                enableSoftwareAES: true,
                manifestLoadingTimeOut: 10000,
                manifestLoadingMaxRetry: 1,
                manifestLoadingRetryDelay: 500,
                manifestLoadingMaxRetryTimeout: 64000,
                levelLoadingTimeOut: 10000,
                levelLoadingMaxRetry: 4,
                levelLoadingRetryDelay: 500,
                levelLoadingMaxRetryTimeout: 64000,
                appendErrorMaxRetry: 3,
                xhrSetup: function(xhr, url) {
                    xhr.withCredentials = true; // do send cookies
                },
                abrEwmaFastLive: 5.0,
                abrEwmaSlowLive: 9.0,
                abrEwmaFastVoD: 4.0,
                abrEwmaSlowVoD: 15.0,
                abrEwmaDefaultEstimate: 500000,
                abrBandWidthFactor: 0.95,
                abrBandWidthUpFactor: 0.7
            };

            var hls = new hlsplayer(config);

            hls.loadSource(self.getMediaUrl());
            hls.attachMedia(video);

            hls.on(hlsplayer.Events.MANIFEST_PARSED, function(event, data) {
                hls_stream_data.stream_levels = hls.levels;
                //console.log("MANIFEST loaded, found " + data.levels.length + " QUALITY LEVEL");

                self.setPreferredQuality(self.config.quality);
            });

            hls.once(hlsplayer.Events.LEVEL_LOADED, function(event, data) {
                self.setState(self.states.BUFFERING);
                self.duration = Math.floor(utils.sToMs(data.details.totalduration)); // convert secs to miliseconds
            });


            // In HLS PLAYER, error also includes bufferring. Error is differentiated into fata & non-fatal
            hls.on(hlsplayer.Events.ERROR, function(event, data) {
                console.warn('ERROR', data);

                if (data.fatal) {
                    self.config.setup_error = true;
                    self.trigger.call(self, self.events.ERROR, data.type);

                    switch (data.type) {
                        case hlsplayer.ErrorTypes.NETWORK_ERROR:
                            console.log("fatal network error encountered, try to recover"); // try to recover network error
                            hls.startLoad();
                            break;
                        case hlsplayer.ErrorTypes.MEDIA_ERROR:
                            console.log("fatal media error encountered, try to recover"); // try to recover media error
                            hls.recoverMediaError();
                            break;
                        default:
                            hls.destroy(); // cannot recover
                            break;
                    }
                } else {
                    switch (data.details) {
                        case 'bufferStalledError':
                        case 'bufferNudgeOnStall':
                            self.setState(self.states.BUFFERING);
                            break;
                    }
                }
            });

            if (debug) {

                var levelNames = {
                    0: "low",
                    1: "medium",
                    2: "high"
                }

                var frags = {},
                    $hlsConsoleLog = $('#hlsConsoleLog');

                var addToConsoleLog = function(str) {
                    var d = new Date();
                    $hlsConsoleLog.html($hlsConsoleLog.html() + "[" + d.toLocaleTimeString() + "] " + str + "\n");

                    if ($hlsConsoleLog[0])
                        $hlsConsoleLog.scrollTop($hlsConsoleLog[0].scrollHeight);
                }

                $('#hlsConsoleFragments').empty();
                $hlsConsoleLog.empty();

                hls.on(hlsplayer.Events.LEVEL_SWITCHING, function(e, data) {
                    $('#hlsConsoleQualityNext').html(levelNames[data.level]);
                    $('#hlsConsoleBitrate').html(data.bitrate);
                    addToConsoleLog("Request level change to '" + levelNames[data.level] + "'");
                });

                hls.on(hlsplayer.Events.LEVEL_SWITCHED, function(e, data) {
                    $('#hlsConsoleQuality').html(levelNames[data.level]);
                    addToConsoleLog("Level change to " + levelNames[data.level]);
                });

                hls.on(hlsplayer.Events.LEVEL_LOADED, function(e, data) {
                    $('#hlsConsoleFragsTotal').html(data.details.endSN);
                    $('#hlsConsoleFragsTotal2').html(data.details.endSN);
                    $('#hlsConsoleDuration').html(data.details.totalduration.toFixed(4) + ' secs');
                });

                hls.on(hlsplayer.Events.FRAG_LOADING, function(e, data) {

                    var fragDate = new Date(null);
                    fragDate.setSeconds(data.frag.start);

                    var el = document.createElement('div');
                    el.classList.add('hlsConsoleFrag');
                    el.classList.add(levelNames[data.frag.level]);

                    el.title = "Fragment " + data.frag.sn + "\nQuality " + levelNames[data.frag.level] + "\n" + data.frag.duration + " seconds\nFrom " + fragDate.getMinutes() + ':' + fragDate.getSeconds();

                    frags[data.frag.sn] = el;
                    $('#hlsConsoleFragments').append(el);

                    addToConsoleLog("Start loading fragment " + data.frag.sn);
                });

                hls.on(hlsplayer.Events.FRAG_LOADED, function(e, data) {
                    var hlsConsoleFragsLoaded = document.getElementById('hlsConsoleFragsLoaded');
                    $('#hlsConsoleFragsLoaded').html(data.frag.sn);

                    if (frags[data.frag.sn])
                        frags[data.frag.sn].title += "\nLoaded in " + parseInt(data.stats.tload - data.stats.tfirst) + "ms";

                    addToConsoleLog("Loaded fragment " + data.frag.sn);
                });

                hls.on(hlsplayer.Events.FRAG_BUFFERED, function(e, data) {
                    $('#hlsConsoleFragsBuffered').html(data.frag.sn);

                    if (frags[data.frag.sn])
                        frags[data.frag.sn].title += "\nBuffered in " + parseInt(data.stats.tbuffered - data.stats.tload) + "ms";

                    addToConsoleLog("Buffered fragment " + data.frag.sn);

                });

                hls.on(hlsplayer.Events.BUFFER_EOS, function(e) {
                    addToConsoleLog("Map buffering ended");
                });

                hls.on(hlsplayer.Events.FPS_DROP, function(e, data) {
                    addToConsoleLog("Dropped " + data.currentDropped + " frames");
                });

                hls.on(hlsplayer.Events.STREAM_STATE_TRANSITION, function(e, data) {
                    $('#hlsConsoleStatus').html(data.nextState);
                    addToConsoleLog("Stream goes from " + data.previousState + " to " + data.nextState);
                });

            }


            video.addEventListener('seeking', this.handleVideoEvent.bind(this));
            video.addEventListener('seeked', this.handleVideoEvent.bind(this));

            video.addEventListener('pause', this.handleVideoEvent.bind(this));
            video.addEventListener('play', this.handleVideoEvent.bind(this));
            video.addEventListener('playing', this.handleVideoEvent.bind(this));
            video.addEventListener('ended', this.handleVideoEvent.bind(this));

            video.addEventListener('error', this.handleVideoEvent.bind(this));
            video.addEventListener('durationchange', this.handleVideoEvent.bind(this));

            video.addEventListener('timeupdate', function() {
                if (hls.currentLevel >= 0)
                    sessionStorage.setItem('lastPlayerLevel', hls.currentLevel);

                hls_stream_data.stream_level_current = hls.currentLevel;
                self.trigger(self.events.TIME_CHANGE, utils.sToMs(video.currentTime));
            });


            self_player = hls;

        }
    };

    me.play = function() {
        $('#in-game_video')[0].play();
    };
    me.stop = function() {
        self_player.detachMedia();
        delete hls_stream_data.stream_levels;
    }

    /*me.pause = delegate('pause');
    me.resume = delegate('play');*/

    me.getDuration = function() {
        return this.duration;
    };
    me.getPosition = function() {
        var getCurrentTime = $('#in-game_video')[0].currentTime;
        return getCurrentTime;
    };
    me.setPosition = function(time) {
        $('#in-game_video')[0].currentTime = utils.msToS(time);
    };

    me.handleVideoEvent = function(event) {
        var data = '';
        switch (event.type) {
            case 'durationchange':
                if (event.target.duration - lastDuration <= 0.5) {
                    return; // some browsers reports several duration change events with almost the same value ... avoid spamming video events
                }
                lastDuration = event.target.duration;
                data = Math.round(event.target.duration * 1000);
                break;
            case 'pause':
            case 'ended':
                lastStartPosition = event.target.currentTime;
                this.setState(this.states.PAUSED);
                break;
            case 'seeking':
            case 'seeked':
            case 'play':
                lastStartPosition = event.target.currentTime;
                hls_stream_data.stream_level_current = self_player.currentLevel;
                break;
            case 'playing':
                lastStartPosition = event.target.currentTime;
                this.setState(this.states.PLAYING);
                break;
            case 'error':
                data = Math.round(event.target.currentTime * 1000);
                if (event.type === 'error') {
                    var errorTxt, mediaError = event.currentTarget.error;
                    switch (mediaError.code) {
                        case mediaError.MEDIA_ERR_ABORTED:
                            errorTxt = "You aborted the video playback";
                            break;
                        case mediaError.MEDIA_ERR_DECODE:
                            errorTxt = "The video playback was aborted due to a corruption problem or because the video used features your browser did not support";
                            break;
                        case mediaError.MEDIA_ERR_NETWORK:
                            errorTxt = "A network error caused the video download to fail part-way";
                            break;
                        case mediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
                            errorTxt = "The video could not be loaded, either because the server or network failed or because the format is not supported";
                            break;
                    }
                    console.error(errorTxt);
                }
                break;
            default:
                break;
        }
    };

    /*me.setVolume = delegate('setVolume');
    me.getVolume = delegate('getVolume');*/

    me.canSetPreferredQuality = function() {
        return !bowser.safari; // Safari uses native HLS, which does not support setting a preferred bitrate
    };
    me.getCurrentQuality = function() {
        var currentQuality = hls_stream_data.stream_level_current;
        this.config.bitrate = (currentQuality > -1 ? hls_stream_data.stream_levels[currentQuality].bitrate + ' kbps' : 'auto');

        return this.config.bitrate;
    };
    me.setPreferredQuality = function(quality) {
        this.config.quality = quality;

        var availableQualities = hls_stream_data.stream_levels;
        if (!availableQualities) {
            return;
        }

        var sortedQualities = _(availableQualities).sortBy('bitrate').value();
        var qualityIndex = {
            highest: _.findIndex(availableQualities, {
                bitrate: _.last(sortedQualities).bitrate
            }),
            lowest: _.findIndex(availableQualities, {
                bitrate: _.first(sortedQualities).bitrate
            }),
        }[quality];

        self_player.nextLevel = (qualityIndex === undefined ? -1 : qualityIndex); // -1 for automatic level selection.
        self_player.loadLevel = (qualityIndex === undefined ? -1 : qualityIndex); // -1 for automatic level selection.

        var trackQuality = (qualityIndex === undefined ? 'auto' : sortedQualities[qualityIndex].bitrate + ' kbps');
        this.trigger(this.events.QUALITY_CHANGE, trackQuality);
    };

    me.resetPlayerErrorFlag = function() {
        if (!!this.config.setup_error) {
            this.config.setup_error = false;
        }
    };

    me.getPoster = function() {
        return this.config.image;
    };
    me.setPoster = function(url) {
        this.config.image = url;
    };


    return HLSPlayer;

});