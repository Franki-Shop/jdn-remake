define([
    'lodash'
], function(
    _
) {
    'use strict';

    var STATE_COLORS = 'background: lemonchiffon';

    // Wrapper that provides a unified API for video playback,
    // i.e. abstracts the implementational differences between actual video players.
    function VideoPlayer() {
        this.state = this.states.UNINSTANTIATED;
        this.callbacks = {};
        this.config = {
            loop: false,
            quality: 'auto',
        };
        this.dimensions = {};
    }
    var me = VideoPlayer.prototype;
    var NOT_IMPLEMENTED = function() {
        throw 'Not implemented';
    };

    // Add an event callback to a given event type
    // Arg types      String, Function
    me.on = function(ev, callback) {
        if (!this.events[ev]) {
            throw 'No such event: ' + ev;
        }
        if (!_.isArray(this.callbacks[ev])) {
            this.callbacks[ev] = [];
        }
        this.callbacks[ev].push(callback);
    };

    // Add an event callback to a given event type, that is called only once, then removed
    // Arg types        String, Function
    me.once = function(ev, callback) {
        var onEvent = function() {
            this.off(ev, onEvent);
            callback.apply(null, arguments);
        }.bind(this);
        this.on(ev, onEvent);
    };

    // Removes an event callback from a given event type. If no callback is provided, all callbacks for the given event
    // type will be removed.
    // Arg types       String, Function
    me.off = function(ev, callback) {
        if (!ev) {
            this.callbacks = {};
            return;
        }
        if (!_.isArray(this.callbacks[ev])) {
            return;
        }
        if (callback) {
            this.callbacks[ev] = _.without(this.callbacks[ev], callback);
            return;
        }
        delete this.callbacks[ev];
    };

    // Trigger an event with the provided event type and optional parameters.
    // Arg types           String, [Any, ...]
    me.trigger = function(ev) {
        if (!this.events[ev]) {
            throw 'No such event: ' + ev;
        }
        if (!_.isArray(this.callbacks[ev])) {
            return;
        }
        var eventParams = _.rest(arguments);
        _.each(this.callbacks[ev], function(callback) {
            callback.apply(this, eventParams);
        }, this);
    };

    // Start buffering a video resource from the given URL. Will not automatically start playing!
    // Arg types        String
    me.load = function(mediaUrl) {
        this.mediaUrl = mediaUrl || this.mediaUrl;

        if (this.mediaUrl) {
            console.log('Video player loading', this.mediaUrl);
        } else {
            throw 'No media url specified';
        }

        this.setState(this.states.BUFFERING);
    };

    // Start playing the loaded video resource, when ready
    me.play = NOT_IMPLEMENTED;

    // Pause playback (remember position)
    me.pause = NOT_IMPLEMENTED;

    // Resume playback from the current position
    me.resume = NOT_IMPLEMENTED;

    // Stop playback (set position to 0)
    me.stop = NOT_IMPLEMENTED;

    // Set configuration parameters. Implementing players can do what they please with them
    me.configure = function(config) {
        this.config = config;
    };

    // Current video length, in milliseconds
    me.getDuration = NOT_IMPLEMENTED;

    // Current player position, in milliseconds
    me.canSetPosition = function() {
        return true;
    };
    me.setPosition = NOT_IMPLEMENTED;
    me.getPosition = NOT_IMPLEMENTED;

    // Current player volume, in the interval [0, 100]
    me.setVolume = NOT_IMPLEMENTED;
    me.getVolume = NOT_IMPLEMENTED;

    // Returns the URL String that was specified when load() was called
    me.getMediaUrl = function() {
        return this.mediaUrl;
    };

    // Returns the playback speed as a Number.
    me.getSpeed = function() {
        return 1;
    };
    me.setSpeed = NOT_IMPLEMENTED;

    // Returns the video player container HTMLElement, jQuery wrapped
    me.getElement = function() {
        return this.$container;
    };
    me.setParentElement = function($parent) {
        $parent.append(this.$container);
    };

    // Set an image that will be displayed when the video is not playing
    me.getPoster = NOT_IMPLEMENTED;
    me.setPoster = NOT_IMPLEMENTED;

    // Set the video player state. Second argument is optional and only used for debugging purposes
    me.setState = function(state, ev) {
        var extraInfo = ev && ev.type ? '(triggered by ' + ev.type + ')' : '';

        if (!this.states[state]) {
            throw 'No such state: ' + state;
        }

        if (state === this.state) {
            console.log('Video player already in state ' + state + '. No action.', extraInfo);
            return;
        }

        console.log('%c Video player state change ', STATE_COLORS, this.state, '→', state, extraInfo);

        var prevState = this.state;
        this.state = state;
        this.trigger(this.events.STATE_CHANGE, state, prevState);
    };
    me.getState = function() {
        return this.state || this.states.UNINSTANTIATED;
    };

    me.isPlaying = function() {
        return this.state === this.states.PLAYING;
    };

    me.getWidth = function() {
        return this.dimensions.width;
    };
    me.getHeight = function() {
        return this.dimensions.height;
    };

    me.canResize = function() {
        return true;
    };
    me.resize = function(width, height) {
        width && (this.dimensions.width = width);
        height && (this.dimensions.height = height);
        this.trigger(this.events.RESIZE, width, height);
    };

    me.canSetPreferredQuality = function() {
        return false;
    };
    me.setPreferredQuality = NOT_IMPLEMENTED;
    me.getPreferredQuality = function() {
        return this.config.quality;
    };
    me.getCurrentQuality = function() {
        return '1000kpbs';
    };

    me.getLoop = function() {
        return this.config.loop;
    };
    me.setLoop = function(loop) {
        this.config.loop = loop;
    };

    me.states = {
        // The player is not yet ready to do anything, except being load():ed
        UNINSTANTIATED: 'UNINSTANTIATED',

        // Playback has been requested (e.g. by calling play()),
        // but sufficient data to start playback has to be loaded first.
        BUFFERING: 'BUFFERING',

        // The player is ready to start playing content (without any buffering)
        IDLE: 'IDLE',

        // The video is currently playing.
        PLAYING: 'PLAYING',

        // The video is currently paused.
        PAUSED: 'PAUSED'
    };

    // Additional arguments passed to the listeners are in the comments
    me.events = {
        RESIZE: 'RESIZE', // width (px), height (px)
        STATE_CHANGE: 'STATE_CHANGE', // state, prevState
        TIME_CHANGE: 'TIME_CHANGE', // time (ms), duration (ms)
        ERROR: 'ERROR', // player dependent event
        QUALITY_CHANGE: 'QUALITY_CHANGE'
    };

    return VideoPlayer;

});